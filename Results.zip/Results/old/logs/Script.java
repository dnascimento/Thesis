

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;





class Script {

    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new FileReader("clients.txt"));
        BufferedWriter out = new BufferedWriter(new FileWriter("out.txt"));
        String line;
        int last = 0;
        while ((line = in.readLine()) != null) {
            line = line.replace(" ", "");
            int val = Integer.valueOf(line);
            if (last == 0) {
                last = val;
            } else {
                out.write(new Integer(last + val).toString());
                out.write("\n");
                last = 0;
            }
        }
        in.close();
        out.close();
    }
}
