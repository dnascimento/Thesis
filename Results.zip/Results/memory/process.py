#!/bin/python
from os import listdir, mkdir, rmdir, makedirs
from os.path import isfile, join, exists
from shutil import rmtree


f = open("raw.txt")

d = {'beforeSize': 0, 'afterBytes': 0, 'afterSize': 0, 'totalSize': 0, 'beforeBytes': 0, 'counter': 0}

for line in f:
	if len(line) == 1:
		continue

	d['counter'] = d['counter'] + 1
	val = int(line.split(": ")[1])
	if line.startswith("Before size:"):
		d['beforeSize'] = d['beforeSize'] + val
	elif line.startswith("After bytes:"):
		d['afterBytes'] = d['afterBytes'] + val
	elif line.startswith("After size:"):
		d['afterSize'] = d['afterSize'] + val
	elif line.startswith("Total size of item:"):
		d['totalSize'] = d['totalSize'] + val
	elif line.startswith("Before bytes:"):
		d['beforeBytes']= d['beforeBytes'] + val
f.close()

print d

for key,val in d.items():
	print ("%s : %s" % (key,val/d['counter']))